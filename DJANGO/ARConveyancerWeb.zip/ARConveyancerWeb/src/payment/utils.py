def cent_to_dollar(cent):
    return cent/100

def dollar_to_cent(cent):
    return cent*100