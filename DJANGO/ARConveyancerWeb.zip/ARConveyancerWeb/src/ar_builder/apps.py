from django.apps import AppConfig


class ArBuilderConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ar_builder'
