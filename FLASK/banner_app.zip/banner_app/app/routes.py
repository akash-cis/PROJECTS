import os
from random import shuffle
from config import basedir
import secrets
from app import app, db
from flask.json import jsonify
from flask import render_template, redirect, url_for, flash
from flask_login import login_user, logout_user, login_required, current_user
from app.forms import BannerForm, LoginForm, RegisterForm
from app.models import Banner, User
from sqlalchemy.sql.expression import func, select

@app.route('/', methods=['GET','POST'])
@app.route('/<int:page>', methods=['GET','POST'])
@app.route('/home', methods=['GET','POST'])
@app.route('/home/<int:page>', methods=['GET','POST'])
@login_required
def index(page=1):
    form = BannerForm()
    if form.validate_on_submit():
        for file in form.image.data:
            try:
                rtx = secrets.token_hex(8)
                _, ext = os.path.splitext(file.filename)
                if ext in ['.jpg', '.png', '.jpeg']:
                    filename = rtx + ext
                    file.save('app/static/banners/' + filename)
                    banner = Banner(title=form.title.data, image=filename, user_id=current_user.id)
                    db.session.add(banner)
                else:
                    flash(f'{file.filename} was not able to upload. {ext} files are not supported', 'danger')
            except Exception as e:
                print(e)
                flash(f'{file.filename} was not able to upload.', 'danger')

        db.session.commit()

        flash('All files were uploaded!', 'success')
        redirect(url_for('index'))

    # banners = Banner.query.order_by(func.random()).paginate(page, 12, False)
    # banners = Banner.query.paginate(page, 12, False)
    banners = Banner.query.offset(0).limit(12).all()
    shuffle(banners)

    return render_template('index.html', title='Home', form=form, pages=banners)


@app.route('/show_more_banner/<int:offset>')
def show_more_banner(offset):

    banners = Banner.query.offset(offset).limit(12).all()
    shuffle(banners)
    if not banners:
        return '0'
    return render_template('loaddata.html', banners=banners)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))

    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first_or_404()
        if not user or not user.check_password(form.password.data):
            flash('Email or password is incorrect. Please try again.')
            return redirect(url_for('login'))
        login_user(user, remember=form.remember_me.data)
        return redirect(url_for('index'))
    return render_template('login.html', title='Login', form=form)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))

    form = RegisterForm()

    if form.validate_on_submit():
        user = User(username=form.username.data, email=form.email.data)
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        flash('Registration successful!', 'success')
        return redirect(url_for('login'))

    return render_template('register.html', title='Register', form=form)
    

@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/profile')
def user():
    pass
