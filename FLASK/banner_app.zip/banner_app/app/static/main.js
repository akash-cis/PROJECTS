$(document).ready(function(){
  
  var offset = 12;
  document.getElementById('showmore').addEventListener('click', function (event) {
    req = $.ajax({
      url: '/show_more_banner/' + offset,
      type: 'GET',
      success:function(data){
        // alert(data.length);
        if (data === '0'){
          alert('no data to be loaded!');
          $('#showmore').hide();
        }else{
          $('#loaddata').append(data);
          offset*=2
        }
      }
    });
  });
});